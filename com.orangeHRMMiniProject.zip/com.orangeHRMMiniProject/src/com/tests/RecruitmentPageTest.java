package tests;

import utils.WebDriverProvider;

import java.time.Duration;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import pages.RecruitmentPage;
import utils.ExcelDataProvider;
import utils.TakeScreenShot;

public class RecruitmentPageTest {
	WebDriver driver;
	RecruitmentPage recruitmentSection;
	LoginPage loginSection;
	ExcelDataProvider excelData;
	String[][] excelDataArray;
	WebDriverProvider webDriverSetter;
	TakeScreenShot screenShot;
	String baseUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
	Logger logger = LogManager.getLogger(RecruitmentPageTest.class.getName());

	@BeforeTest
	public void driverSetUp()

	{
		try {
			webDriverSetter = new WebDriverProvider(driver);
			driver = webDriverSetter.setBrowser("chrome");
			driver.get(baseUrl);
			loginSection = new LoginPage(driver);
			excelData = new ExcelDataProvider();
			screenShot = new TakeScreenShot();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			excelDataArray = excelData.getData();
			loginSection.setLoginPageUsrName(excelDataArray[0][0]);
			loginSection.setLoginPagePassword(excelDataArray[0][1]);
			loginSection.clickLoginPageLoginBtn();
			logger.info("Login completed");

			recruitmentSection = new RecruitmentPage(driver);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 1)
	public void candidateSec() {
		try {
			recruitmentSection.click_recruit();
			recruitmentSection.click_candidate();
			recruitmentSection.jobTitle();
			recruitmentSection.vacancy();
			recruitmentSection.hiringMananger();
			recruitmentSection.status();
			recruitmentSection.CandidateName(excelDataArray[22][0]);
			recruitmentSection.Keywords(excelDataArray[22][1]);
			recruitmentSection.dateOfApplication();
			recruitmentSection.to();
			recruitmentSection.methodOfApplication();
			recruitmentSection.submit();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 2)
	public void vacancySec() {
		try {
			recruitmentSection.recruitment();
			recruitmentSection.click_vacancy();
			recruitmentSection.vac_jobTitle();
			recruitmentSection.vac_vacancy();
			recruitmentSection.vac_HiringMananger();
			recruitmentSection.vac_status();
			recruitmentSection.vac_submit();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@AfterTest
	public void tearDown() {
		try {
			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
