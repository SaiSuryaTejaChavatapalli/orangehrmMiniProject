package tests;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.AdminPage;
import pages.LoginPage;
import utils.ExcelDataProvider;
import utils.TakeScreenShot;
import utils.WebDriverProvider;

//---------------------------
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

//------------------------------------
public class AdminPageTest {
	Actions action;
	WebDriver driver;
	AdminPage adminSection;
	LoginPage loginSection;
	ExcelDataProvider excelData;
	String[][] excelDataArray;
	TakeScreenShot screenShot;
	String baseUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
	WebDriverProvider webDriverSetter;
	Logger logger = LogManager.getLogger(AdminPageTest.class.getName());
	

	@BeforeTest
	public void setUpAdminPage() {
		try {
			webDriverSetter = new WebDriverProvider(driver);
			driver = webDriverSetter.setBrowser("chrome");
			driver.get(baseUrl);
			adminSection = new AdminPage(driver);
			loginSection = new LoginPage(driver);
			action=new Actions(driver);
			excelData = new ExcelDataProvider();
			screenShot = new TakeScreenShot();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			excelDataArray = excelData.getData();
			loginSection.setLoginPageUsrName(excelDataArray[0][0]);
			loginSection.setLoginPagePassword(excelDataArray[0][1]);
			loginSection.clickLoginPageLoginBtn();
			logger.info("Login completed");
		}
		catch(Exception e)
		{
		e.printStackTrace();
		}
		
	}

	@Test(priority = 1)
	public void adminJobTitle(){
		try {
			adminSection.clickAdmin();
			adminSection.clickJob();
			adminSection.clickJobTitles();
			adminSection.clickAddButton();
			adminSection.setJobTitle(excelDataArray[1][0]);
			adminSection.setJobDescription(excelDataArray[1][1]);
			adminSection.clickSaveButton();
			action.pause(Duration.ofSeconds(6)).build().perform();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,100)");
			screenShot.takeSnapShot(driver, "adminJobTitle.png");
			logger.info("Job Title Added");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 2)
	public void adminOrganizationLocationSearch() {
		try {
			adminSection.clickAdmin();
			adminSection.clickOrganization();
			adminSection.clickOrganizationLocation();
			adminSection.setLocationName(excelDataArray[2][0]);
			adminSection.setLocationCity(excelDataArray[2][1]);
			adminSection.clickLocationCountryDropDown();
			adminSection.clicklocationCountryName();
			adminSection.clickSearchButton();
			action.pause(Duration.ofSeconds(6)).build().perform();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,500)");
			screenShot.takeSnapShot(driver, "adminOrganizationSearch.png");
			logger.info("Organization search is completed");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 3)
	public void adminOrganizationLocationAdd(){
		try {
			adminSection.clickAdmin();
			adminSection.clickOrganization();
			adminSection.clickOrganizationLocation();
			adminSection.clickAddButton();
			adminSection.setAddOrgLocationName(excelDataArray[3][0]);
			adminSection.setAddOrgCityName(excelDataArray[3][1]);
			adminSection.setAddOrgStateName(excelDataArray[3][2]);
			adminSection.setAddOrgZipCode(excelDataArray[3][3]);
			adminSection.setAddOrgPhoneNo(excelDataArray[3][4]);
			adminSection.setAddOrgFaxNo(excelDataArray[3][5]);
			adminSection.setAddOrgAddress(excelDataArray[3][6]);
			adminSection.setAddOrgNotes(excelDataArray[3][7]);
			adminSection.clickOrgCountryDropDown();
			adminSection.clickOrgIndiaOption();
			adminSection.clickSaveButton();
			action.pause(Duration.ofSeconds(6)).build().perform();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,500)");
			screenShot.takeSnapShot(driver, "adminOrganizationLocationAdd.png");
			logger.info("Adding location of organization is completed");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(priority = 4)
	public void adminUserManagement(){
		try {
			adminSection.clickAdminUserManagement();
			adminSection.clickAdminUsers();
			adminSection.clickUserRoleDropDown();
			adminSection.clickESSButton();
			adminSection.setUserMngEmpName(excelDataArray[4][0]);
			action.pause(Duration.ofSeconds(5)).build().perform();
			adminSection.clickJoeRootOption();
			adminSection.clickUserMngStatusDropDown();
			adminSection.clickEnabledOption();
			adminSection.clickSearchButton();
			action.pause(Duration.ofSeconds(6)).build().perform();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,500)");
			screenShot.takeSnapShot(driver, "adminUserManagement.png");
			logger.info("admin User Management is completed");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 5)
	public void adminQualificationSkill(){
		try {
			adminSection.setAdmin();
			adminSection.setQualification();
			// move to skill
			adminSection.setSkill();
			// adding of skill
			adminSection.setSkillAdd();
			adminSection.setSkillName(excelDataArray[11][0]);
			adminSection.setSkillDescription(excelDataArray[11][1]);
			adminSection.setSkillSave();
			// add existed Skil
			adminSection.setSkillAdd();
			adminSection.setSkillName(excelDataArray[11][0]);
			adminSection.setSkillDescription(excelDataArray[11][1]);
			adminSection.setSkillCancel();
			// deleting of skill
			adminSection.setSkillDel();
			adminSection.setSkillDelYes();
			// deleting multiple
			adminSection.setSkillMul1();
			adminSection.setSkillMul2();
			adminSection.setSkillMul();
			adminSection.setSkillMulYes();
			// edit Skill
			adminSection.setSkillEdit();
			adminSection.setSkillEditName(excelDataArray[11][2]);
			adminSection.setSkillEditDescription(excelDataArray[11][3]);
			adminSection.setSkillEditSave();
			action.pause(Duration.ofSeconds(6)).build().perform();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,1000)");
			screenShot.takeSnapShot(driver, "adminQualificationSkill.png");
			logger.info("admin Qualification skill is added");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 6)
	public void adminQualificationEducation(){
		try {
			//-
			adminSection.setQualification();
			//move to education
			adminSection.setEducation();
			//adding of education
			adminSection.setEducationAdd();
			adminSection.setEducationName(excelDataArray[12][0]);
			
			adminSection.setEducationSave();
			//add existed education
			adminSection.setEducationAdd();
			adminSection.setEducationName(excelDataArray[12][0]);
			
			adminSection.setEducationCancel();
			
			//edit education
			adminSection.setEducationEdit();
			adminSection.setEducationEditName(excelDataArray[12][1]);
			
			adminSection.setEducationEditSave();
			
			//-------------------------------------------------------
			action.pause(Duration.ofSeconds(6)).build().perform();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,100)");
			screenShot.takeSnapShot(driver, "adminQualificationEducation.png");
			logger.info("Admin qualification education is added");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 7)
	public void adminNationalities() {
		try {
			// move to national
			adminSection.setNational();
			// adding of national
			adminSection.setNationalAdd();
			adminSection.setNationalName(excelDataArray[13][0]);

			adminSection.setNationalSave();
			// add existed National
			adminSection.setNationalAdd();
			adminSection.setNationalName(excelDataArray[13][0]);

			adminSection.setNationalCancel();
			// deleting of national
			adminSection.setNationalDel();
			adminSection.setNationalDelYes();
			// deleting multiple
			adminSection.setNationalMul1();
			adminSection.setNationalMul2();
			adminSection.setNationalMul();
			adminSection.setNationalMulYes();
			// edit national
			adminSection.setNationalEdit();
			adminSection.setNationalEditName(excelDataArray[13][1]);

			adminSection.setNationalEditSave();
			logger.info("Admin Nationalitied is Added &Edited & Deleted");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@AfterTest
	public void quit() {
		try {
			driver.quit();
		}
		catch(Exception e)
		{
		e.printStackTrace();
		}
		
	}
}
