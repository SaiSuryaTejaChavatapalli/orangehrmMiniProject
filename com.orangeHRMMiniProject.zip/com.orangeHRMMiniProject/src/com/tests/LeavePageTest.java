package tests;

import java.time.Duration;

import utils.WebDriverProvider;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import pages.PIMPage;
import utils.ExcelDataProvider;
import utils.TakeScreenShot;
import pages.LeavePage;

public class LeavePageTest {
	Actions action;
	WebDriver driver;
	PIMPage pimSection;
	LoginPage loginSection;
	LeavePage leaveSection;
	ExcelDataProvider excelData;
	TakeScreenShot screenShot;
	WebDriverProvider webDriverSetter;
	String[][] excelDataArray;
	String baseUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
	Logger logger = LogManager.getLogger(LeavePageTest.class.getName());

	@BeforeTest
	public void setUp() {
		try {
			webDriverSetter = new WebDriverProvider(driver);
			driver = webDriverSetter.setBrowser("chrome");
			driver.get(baseUrl);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			pimSection = new PIMPage(driver);
			loginSection = new LoginPage(driver);
			leaveSection = new LeavePage(driver);
			action=new Actions(driver);
			excelData = new ExcelDataProvider();
			screenShot = new TakeScreenShot();
			excelDataArray = excelData.getData();
			loginSection.setLoginPageUsrName(excelDataArray[0][0]);
			loginSection.setLoginPagePassword(excelDataArray[0][1]);
			loginSection.clickLoginPageLoginBtn();
			logger.info("Login Completed");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 1)
	public void Apply() {
		try {
			leaveSection.clickLeave();
			leaveSection.clickApply();
			leaveSection.clickLeaveTypeApply();
			leaveSection.clickname();
			leaveSection.setFrom(excelDataArray[24][0]);
			// leaveSection.setTo();
			// leaveSection.clickDuration();
			// leaveSection.clickDurationDrop();
			leaveSection.clickApplyFromApply();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 2)
	public void Entitlement() {
		try {
			leaveSection.ClickEntitlement();
			leaveSection.ClickAddEntitlement();
			leaveSection.ClickEmpName1(excelDataArray[24][1]);
			action.pause(Duration.ofSeconds(5)).build().perform();
			leaveSection.ClickEmpNameDrop();
			leaveSection.ClickLeaveTypeFromEnt();
			leaveSection.ClickLeaveTypeFromEntDrop();
			leaveSection.setEntitlement(excelDataArray[24][2]);
			leaveSection.ClickSave();
			leaveSection.ClickAlert();
			leaveSection.ClickSearchFromE();
			leaveSection.scroll();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 3)
	public void LeaveList() {
		try {
			leaveSection.ClickLeaveList();

			leaveSection.setFromDateLeave();

			leaveSection.setToDateLeave();

			leaveSection.ClickStatus();

			leaveSection.ClickStatusDrop();

			leaveSection.ClickLeaveType();

			leaveSection.ClickLeaveTypeDrop();

			leaveSection.setEmpName(excelDataArray[24][3]);
			action.pause(Duration.ofSeconds(2)).build().perform();
			leaveSection.ClickEmpNameDropLeave();

			leaveSection.ClickSubUnit();

			leaveSection.ClickSubUnitDrop();
			leaveSection.ClickSearch();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@AfterTest
	public void tearDown() {
		try {
			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
