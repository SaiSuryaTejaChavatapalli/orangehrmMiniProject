package tests;

import java.time.Duration;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import pages.PIMPage;
import pages.LeavePage;
import pages.TimePage;
import utils.ExcelDataProvider;
import utils.TakeScreenShot;
import pages.PerformancePage;
import utils.WebDriverProvider;

public class PerformancePageTest {
	WebDriver driver;
	Actions action;
	PIMPage pimSection;
	LoginPage loginSection;
	LeavePage leaveSection;
	TimePage timeSection;
	PerformancePage performanceSection;
	ExcelDataProvider excelData;
	WebDriverProvider webDriverSetter;
	TakeScreenShot screenShot;
	String[][] excelDataArray;
	String baseUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";

	Logger logger = LogManager.getLogger(PerformancePageTest.class.getName());

	@BeforeTest
	public void setUp() {
		try {
			webDriverSetter = new WebDriverProvider(driver);
			driver = webDriverSetter.setBrowser("chrome");
			driver.get(baseUrl);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			pimSection = new PIMPage(driver);
			action =new Actions(driver);
			loginSection = new LoginPage(driver);
			leaveSection = new LeavePage(driver);
			timeSection = new TimePage(driver);
			performanceSection = new PerformancePage(driver);
			excelData = new ExcelDataProvider();
			screenShot = new TakeScreenShot();
			excelDataArray = excelData.getData();
			loginSection.setLoginPageUsrName(excelDataArray[0][0]);
			loginSection.setLoginPagePassword(excelDataArray[0][1]);
			loginSection.clickLoginPageLoginBtn();
			logger.info("Login Completed");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 1)
	public void performanceSec() {
		try {
			performanceSection.performanceClick();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 2)
	public void empReview() {
		try {
			performanceSection.setEmplyoeeName(excelDataArray[18][0]);
			action.pause(Duration.ofSeconds(2)).build().perform();
			performanceSection.setJobTitle();
			action.pause(Duration.ofSeconds(2)).build().perform();
			performanceSection.setSubUnit();
			action.pause(Duration.ofSeconds(2)).build().perform();
			performanceSection.setStatusReview();
			action.pause(Duration.ofSeconds(2)).build().perform();
			performanceSection.clickClick();
			action.pause(Duration.ofSeconds(2)).build().perform();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 3)
	public void myTrackers() {
		try {
			performanceSection.myTrackers();

			performanceSection.clickView();

			performanceSection.clickAddLogs();
			action.pause(Duration.ofSeconds(4)).build().perform();
			performanceSection.setLog(excelDataArray[18][1]);
			action.pause(Duration.ofSeconds(4)).build().perform();
			performanceSection.clickBotton();
			action.pause(Duration.ofSeconds(4)).build().perform();
			performanceSection.setComment(excelDataArray[18][2]);
			action.pause(Duration.ofSeconds(5)).build().perform();
			performanceSection.clickSave();
			action.pause(Duration.ofSeconds(4)).build().perform();
			performanceSection.clickSetting();

			performanceSection.clickLogEdit();

			performanceSection.clickSaveButton();

			performanceSection.clickSetting1();

			performanceSection.clickLogDelete();

			performanceSection.clickYesDelete();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 4)
	public void empTrackers() {
		try {
			performanceSection.clickEmpTracker();
			performanceSection.seteName(excelDataArray[18][3]);
			action.pause(Duration.ofSeconds(2)).build().perform();
			performanceSection.clickPerformaceSearch();
			action.pause(Duration.ofSeconds(2)).build().perform();
			logger.info("employee trackers is completed");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@AfterTest
	public void tearDown() {
		try {
			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
