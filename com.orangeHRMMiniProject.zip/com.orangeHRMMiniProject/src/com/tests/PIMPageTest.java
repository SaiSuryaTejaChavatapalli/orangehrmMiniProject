package tests;

import utils.WebDriverProvider;
import java.time.Duration;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import pages.PIMPage;
import utils.ExcelDataProvider;
import utils.TakeScreenShot;

public class PIMPageTest {
	Actions act;
	WebDriver driver;
	PIMPage pimSection;
	LoginPage loginSection;
	ExcelDataProvider excelData;
	TakeScreenShot screenShot;
	WebDriverProvider webDriverSetter;
	String[][] excelDataArray;
	String baseUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
	Logger logger = LogManager.getLogger(PIMPageTest.class.getName());

	@BeforeTest
	public void setUp() {
		try {
			webDriverSetter = new WebDriverProvider(driver);
			driver = webDriverSetter.setBrowser("chrome");
			driver.get(baseUrl);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			act=new Actions(driver);
			pimSection = new PIMPage(driver);
			loginSection = new LoginPage(driver);
			excelData = new ExcelDataProvider();
			screenShot = new TakeScreenShot();
			excelDataArray = excelData.getData();
			loginSection.setLoginPageUsrName(excelDataArray[0][0]);
			loginSection.setLoginPagePassword(excelDataArray[0][1]);
			loginSection.clickLoginPageLoginBtn();
			logger.info("Login Completed");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 1)
	public void pimAddEmployee() {
		try {
			pimSection.clickPimTab();
			pimSection.clickPimAddEmpTab();
			pimSection.setPimFstName(excelDataArray[6][0]);
			pimSection.setPimLstName(excelDataArray[6][1]);
			pimSection.setPimEmpId(excelDataArray[6][2]);
			pimSection.clickSaveButton();
			act.pause(Duration.ofSeconds(5)).build().perform();
			screenShot.takeSnapShot(driver, "pimAddEmployee.png");
			logger.info("PIM-Employee Added");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 2)
	public void pimSearchEmployee() {
		try {
			pimSection.clickPimTab();
			pimSection.clickPimEmpListTab();
			pimSection.setpimEmpListEmpId(excelDataArray[7][0]);
			pimSection.clickSearchButton();
			act.pause(Duration.ofSeconds(5)).build().perform();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,500)");
			screenShot.takeSnapShot(driver, "pimSearchEmployee.png");
			logger.info("PIM-Seach Employee is Searched");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 3)
	public void pimReportAdd() {
		try {
			pimSection.clickPimTab();
			pimSection.clickPimReportsTab();
			pimSection.clickAddButton();
			pimSection.setPimRprtName(excelDataArray[8][0]);
			pimSection.clickPimRprtSelCriteriaDrpDn();
			// Service period
			pimSection.clickPimRprtSelServicePeriodOption();
			pimSection.clickPimRprtSelDisFieldGrpDrpDn();
			// Supervisor
			pimSection.clickPimRprtSelDispGrpSupervisorOption();
			pimSection.clickPimRprtSelDispFieldDrpDn();
			// Reporting Method
			pimSection.clickPimRprtSelDispFieldRprtMethOption();
			pimSection.clickPimRprtPlusBtn();
			pimSection.clickSaveButton();
			logger.info("PIM Report is added");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 4)
	public void pimReportSearch() {
		try {
			pimSection.clickPimTab();
			pimSection.clickPimReportsTab();
			pimSection.setPimRprtNameSearch(excelDataArray[9][0]);
			act.pause(Duration.ofSeconds(3)).build().perform();
			pimSection.clickTejasReportOption();
			pimSection.clickSearchButton();
			act.pause(Duration.ofSeconds(5)).build().perform();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,500)");
			screenShot.takeSnapShot(driver, "pimReportSearch.png");
			logger.info("PIM Report is serached");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@AfterTest
	public void tearDown() {
		try {
			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
