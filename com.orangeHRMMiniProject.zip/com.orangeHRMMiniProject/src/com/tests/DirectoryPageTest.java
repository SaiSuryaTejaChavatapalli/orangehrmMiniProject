package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.DirectoryPage;
import pages.LoginPage;
import utils.ExcelDataProvider;
import utils.TakeScreenShot;
import utils.WebDriverProvider;

public class DirectoryPageTest {
	WebDriver driver;
	Actions action;
	public String baseUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
	DirectoryPage directoryPage;
	LoginPage loginSection;
	ExcelDataProvider excelData;
	TakeScreenShot screenShot;
	WebDriverProvider webDriverSetter;
	Logger logger = LogManager.getLogger(DirectoryPageTest.class.getName());

	@BeforeTest
	public void driverSetUp(){
		try {
			webDriverSetter = new WebDriverProvider(driver);
			driver = webDriverSetter.setBrowser("chrome");
			driver.get(baseUrl);
			excelData = new ExcelDataProvider();
			loginSection = new LoginPage(driver);
			directoryPage = new DirectoryPage(driver);
			screenShot = new TakeScreenShot();
			action=new Actions(driver);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			String[][] excelDataArray = excelData.getData();
			loginSection.setLoginPageUsrName(excelDataArray[0][0]);
			loginSection.setLoginPagePassword(excelDataArray[0][1]);
			loginSection.clickLoginPageLoginBtn();
			logger.info("logined into OrangeHRM");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 1)
	public void directorySec() throws Exception {
		directoryPage.filter_click();
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(
				"C:\\Users\\sai_chavatapalli\\eclipse-workspace\\com.orangeHRMMiniProject\\Resources\\data.properties");

		try {
			prop.load(fis);

			String val1 = prop.getProperty("Employee_Name");
			directoryPage.Employee_Name(val1);
			directoryPage.Employee_name(Keys.ARROW_DOWN);
			directoryPage.Employee_name(Keys.ENTER);
			action.pause(Duration.ofSeconds(3)).build().perform();
			logger.info("Employee_Name is given");

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			fis.close();
		}
		
		directoryPage.Job_Title();
		directoryPage.Title_Selection();
		action.pause(Duration.ofSeconds(2)).build().perform();
		logger.info("Job_Title is Selected");
		directoryPage.Location();
		directoryPage.Location_Selection();
		action.pause(Duration.ofSeconds(2)).build().perform();
		logger.info("Location is Selected");
		directoryPage.Search();
		action.pause(Duration.ofSeconds(2)).build().perform();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,300)");
		action.pause(Duration.ofSeconds(5)).build().perform();

		driver.findElement(By.cssSelector(".oxd-sheet.oxd-sheet--rounded.oxd-sheet--white.orangehrm-directory-card"))
				.click();
		js.executeScript("window.scrollBy(0,100)");
		action.pause(Duration.ofSeconds(3)).build().perform();
		// ------------------------
		screenShot.takeSnapShot(driver, "Directory.png");

		// --------------------------
		logger.info("employee details are displayed");

	}

	@AfterTest
	public void tearDown() {
		try {
			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}