package tests;

import java.time.Duration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.MyInfoPersonalDetailsPage;
import utils.ExcelDataProvider;
import pages.MyInfoContactDetailsPage;
import pages.*;

import utils.WebDriverProvider;

@Test
public class MyInfoPageTest {
	WebDriver driver;
	MyInfoContactDetailsPage myInfoContactSection;
	MyInfoPersonalDetailsPage myInfoPersonalDetailSection;
	LoginPage loginSection;
	ExcelDataProvider excelData;
	String[][] excelDataArray;
	WebDriverProvider webDriverSetter;
	String baseUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
	Logger logger = LogManager.getLogger(MyInfoPageTest.class.getName());

	@BeforeTest
	public void driverSetUp() {
		try {
			logger.info("SetUp Started");
			webDriverSetter = new WebDriverProvider(driver);
			driver = webDriverSetter.setBrowser("chrome");
			driver.get(baseUrl);
			myInfoContactSection = new MyInfoContactDetailsPage(driver);
			myInfoPersonalDetailSection = new MyInfoPersonalDetailsPage(driver);
			loginSection = new LoginPage(driver);
			excelData = new ExcelDataProvider();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			excelDataArray = excelData.getData();
			loginSection.setLoginPageUsrName(excelDataArray[0][0]);
			loginSection.setLoginPagePassword(excelDataArray[0][1]);
			loginSection.clickLoginPageLoginBtn();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 1)
	public void myInfoSec() {
		try {
			// methods called for personal details module
			logger.info("Personal Information is started");
			myInfoPersonalDetailSection.clickMyInfoTab();
			myInfoPersonalDetailSection.clickPersonalDetailsTab();
			myInfoPersonalDetailSection.firstname(excelDataArray[15][0]);
			myInfoPersonalDetailSection.middlename(excelDataArray[15][1]);
			myInfoPersonalDetailSection.lastname(excelDataArray[15][2]);
			myInfoPersonalDetailSection.nickname(excelDataArray[15][3]);
			myInfoPersonalDetailSection.employee_id(excelDataArray[15][4]);
			myInfoPersonalDetailSection.other_id(excelDataArray[15][5]);
			myInfoPersonalDetailSection.lisence(excelDataArray[15][6]);
			myInfoPersonalDetailSection.ssn_no(excelDataArray[15][7]);
			myInfoPersonalDetailSection.sin_no(excelDataArray[15][8]);
			myInfoPersonalDetailSection.saveButton();
			logger.info("Personal Information is completed");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 2)
	public void myInfoContactDetails() {
		try {
			// methods called for contact details module
			logger.info("contact details is started");
			myInfoContactSection.clickMyInfoTab();
			myInfoContactSection.clickContactDetailsTab();
			myInfoContactSection.street1(excelDataArray[16][0]);
			myInfoContactSection.street2(excelDataArray[16][1]);
			myInfoContactSection.city(excelDataArray[16][2]);
			myInfoContactSection.state(excelDataArray[16][3]);
			myInfoContactSection.zip(excelDataArray[16][4]);
			myInfoContactSection.country();
			myInfoContactSection.home(excelDataArray[16][5]);
			myInfoContactSection.mobile(excelDataArray[16][6]);
			myInfoContactSection.work(excelDataArray[16][7]);
			myInfoContactSection.email(excelDataArray[16][8]);
			myInfoContactSection.o_email(excelDataArray[16][9]);
			myInfoContactSection.clickLast();
			logger.info("contact details is completed");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@AfterTest
	public void tearDown() {
		try {
			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
