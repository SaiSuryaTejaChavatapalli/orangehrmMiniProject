package tests;

import java.time.Duration;

import utils.WebDriverProvider;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import pages.PIMPage;
import pages.LeavePage;
import pages.TimePage;
import utils.ExcelDataProvider;
import utils.TakeScreenShot;

public class TimePageTest {
	WebDriver driver;
	Actions action;
	PIMPage pimSection;
	LoginPage loginSection;
	LeavePage leaveSection;
	TimePage timeSection;
	ExcelDataProvider excelData;
	TakeScreenShot screenShot;
	WebDriverProvider webDriverSetter;
	String[][] excelDataArray;
	String baseUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
	Logger logger = LogManager.getLogger(TimePageTest.class.getName());

	@BeforeTest
	public void setUp() {
		try {
			webDriverSetter = new WebDriverProvider(driver);
			driver = webDriverSetter.setBrowser("chrome");
			driver.get(baseUrl);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			action=new Actions(driver);
			pimSection = new PIMPage(driver);
			loginSection = new LoginPage(driver);
			leaveSection = new LeavePage(driver);
			timeSection = new TimePage(driver);
			excelData = new ExcelDataProvider();
			screenShot = new TakeScreenShot();
			excelDataArray = excelData.getData();
			loginSection.setLoginPageUsrName(excelDataArray[0][0]);
			loginSection.setLoginPagePassword(excelDataArray[0][1]);
			loginSection.clickLoginPageLoginBtn();
			logger.info("Login Completed");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 1)
	public void Attendance() {
		try {
			timeSection.ClickTime();
			timeSection.ClickAttendance();
			timeSection.ClickMyRecord();
			timeSection.ClickViewRecord();
			timeSection.scroll();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 2)
	public void Reports() {
		try {
			timeSection.clickReport();
			timeSection.clickProjectReports();
			timeSection.setProjectName();
			action.pause(Duration.ofSeconds(4)).build().perform();
			timeSection.selectProjectName();
			timeSection.setFrom();
			timeSection.setTo();
			timeSection.clickView();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 3)
	public void ProjectInfo() {
		try {
			timeSection.clickProjectInfo();
			timeSection.clickCustomer();
			timeSection.clickAdd();
			timeSection.setCustomerName(excelDataArray[20][0]);
			timeSection.setDiscription(excelDataArray[20][1]);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 4)
	public void Timesheet() {
		try {
			timeSection.ClickTimeSheet();
			timeSection.ClickmyTimeSheet();
			timeSection.ClickEdit();
			timeSection.setprojectNameTS();
			timeSection.setprojectNameDrop();
			timeSection.setActivity();
			timeSection.setActivityDrop();

			timeSection.setMon();
			timeSection.Clicksave();
			timeSection.ClickSubmit();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@AfterTest
	public void tearDown() {
		try {
			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
