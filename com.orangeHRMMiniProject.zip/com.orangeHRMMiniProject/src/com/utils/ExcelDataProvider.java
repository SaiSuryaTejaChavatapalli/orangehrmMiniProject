package utils;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.WebDriver;

	
public class ExcelDataProvider {
	String[][] data ;
	public static WebDriver driver;
    	ReadExcel readex = new ReadExcel();
    	public static Sheet sh;
    	
    	
    	public String[][] getData() throws InvalidFormatException, IOException {
    	String filePath="C:\\Users\\sai_chavatapalli\\eclipse-workspace\\com.orangeHRMMiniProject\\Resources";
    	 String fileName="miniProject.xlsx";
    	 String sheetName="Sheet1";
    	 
    	 sh= readex.readExcel(filePath, fileName, sheetName);
    	 
    	 int totalRows= sh.getLastRowNum();
    	 Row firstRow = sh.getRow(0);
    	 int totalCols =firstRow.getLastCellNum();
    	 
    	 data = new String[totalRows][totalCols+1];
    	 DataFormatter format=new DataFormatter();
    	 for(int i=1;i<totalRows+1;i++) {
    	 for(int j=0;j<totalCols;j++) {
    	 data[i-1][j]=format.formatCellValue(sh.getRow(i).getCell(j));  
    	 }
    	 }
    	 //System.out.println(Arrays.deepToString(data));
    	 return data;
		}
    
}