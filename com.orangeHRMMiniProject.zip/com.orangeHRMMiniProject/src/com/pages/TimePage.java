package pages;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//-----------------
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import org.openqa.selenium.support.PageFactory;


public class TimePage {
	Logger logger = LogManager.getLogger(TimePage.class.getName());
		WebDriver driver;
		public TimePage(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
			}
			

		@FindBy(xpath="//span[normalize-space()='Time']")
		WebElement Time;



		@FindBy(xpath="//span[normalize-space()='Attendance']")
		WebElement Attendance;

		@FindBy(xpath ="//a[normalize-space()='My Records']")
		WebElement myRecord;

		@FindBy(xpath ="//button[@type='submit']")
		WebElement viewRecord;

		@FindBy(xpath="//a[normalize-space()='Punch In/Out']")
		WebElement punchInOut;

		@FindBy(tagName="textarea")
		WebElement note;

		@FindBy(xpath = "(//button[normalize-space()='In'])[1]")
		WebElement In;
		
		@FindBy(xpath="//textarea[@placeholder='Type here']")
		WebElement noteOut;
		
		@FindBy(xpath = "(//button[normalize-space()='Out'])[1]")
		WebElement clickOut;

		//---------------------------------------------
		@FindBy(xpath = "//a[normalize-space()='Employee Records']")
		WebElement empRecord;

		@FindBy(xpath = "//input[@placeholder='Type for hints...']")
		WebElement empRecordName;
		
		
		//-----
		@FindBy(xpath = "//span[contains(text(),'Lisa')]")
		WebElement empRecordNameDrop;
		
		

		@FindBy(xpath = "//button[@type='submit']")
		WebElement clickView;


		public void ClickTime() {
			Time.click();
			logger.info("Time tab clicked");
		}
		
		public void ClickAttendance() {
			Attendance.click();
			logger.info("Attendance tab clicked");
		}
		
		public void ClickMyRecord() {
			myRecord.click();
			logger.info("My record subtab clicked");
		}
		
		public void ClickViewRecord() {
			viewRecord.click();
			logger.info("viewRecord clicked");
		}
		
		public void scroll(){
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("window.scrollBy(0,3000)");
			
			logger.info("Scrolling is done");
		}
		
		
		public void ClickPunchInOut() {
			punchInOut.click();
			logger.info("Punch in/out tab clicked");
		}
		
		public void setNote(String Name) {
			note.sendKeys(Name);
			logger.info("note In is set");
		}
		
		public void ClickIn() {
			In.click();
			logger.info("In clicked");
		}
		public void setNoteOut(String Name) {
			noteOut.sendKeys(Name);
			logger.info("noteOut is set");
		}
		public void clickOut() {
			clickOut.click();
			logger.info("Out clicked");
		}
		
		//---------------------------------------------------------------------------
		@FindBy(xpath = "//span[normalize-space()='Reports']")
		WebElement reports;
		

		@FindBy(xpath = "//a[normalize-space()='Project Reports']")
		WebElement ProjectReports;
		@FindBy(xpath = "//input[@placeholder='Type for hints...']")
		WebElement ProjectName;
		
		@FindBy(xpath = "//div[@role='listbox']//div[2]")
		WebElement ProjectNameDrop;
		
		@FindBy(xpath = "//input[@placeholder='From']")
		WebElement From;
		
		@FindBy(xpath = "//input[@placeholder='To']")
		WebElement To;
		
		@FindBy(xpath = "//button[normalize-space()='View']")
		WebElement View;
		
		public void clickReport() {
			reports.click();
			logger.info("reports is clicked");
		}
		
		public void clickProjectReports() {
			ProjectReports.click();
			logger.info("ProjectReports is clicked");
		}
		public void setProjectName(){
			ProjectName.sendKeys("a");
			logger.info("A is sent");
			
		}	
		public void selectProjectName(){
			ProjectNameDrop.click();
			logger.info("ProjectNameDrop is clicked");
		}
		
		public void setFrom() {
			From.sendKeys("2022-10-11");
			logger.info("date is sent");
			
		}
		
		public void setTo() {
			To.sendKeys("2022-10-12");
			logger.info("date is sent");
		}
		public void clickView() {
			View.click();
			logger.info("View is clicked");
		}
		
		
		
		
		
		@FindBy(xpath = "//span[normalize-space()='Project Info']")
		WebElement projectInfo;

		@FindBy(xpath = "//a[normalize-space()='Customers']")
		WebElement customer;

		@FindBy(xpath="//i[@class='oxd-icon bi-plus oxd-button-icon']")
		WebElement Add;

		@FindBy(xpath="//div[@class='oxd-input-group oxd-input-field-bottom-space']//div//input[@class='oxd-input oxd-input--active']")
		WebElement customerName;

		@FindBy(xpath = "//textarea[@placeholder='Type description here']")
		WebElement discription;

		@FindBy(xpath = "//button[normalize-space()='Save']")
		WebElement SaveInPI;

		
		public void clickProjectInfo() {
			projectInfo.click();
		}
		
		public void clickCustomer() {
			customer.click();
		}
		public void clickAdd() {
			Add.click();
		}
		public void setCustomerName(String Name) {
			customerName.sendKeys(Name);
		}
		public void setDiscription(String disc) {
			discription.sendKeys(disc);
		}
		

		//TimeSheet--------------------------------------------------------------------------

		@FindBy(xpath="//span[normalize-space()='Timesheets']")
		WebElement TimeSheet;

		@FindBy(xpath = "//a[normalize-space()='My Timesheets']")
		WebElement myTimeSheet;
		
		@FindBy(xpath="//button[normalize-space()='Edit']")
		WebElement Edit;

		@FindBy(xpath="//i[@class='oxd-icon bi-trash']")
		WebElement delete;

		@FindBy(xpath="//input[@placeholder='Type for hints...']")
		WebElement projectName;
		
		@FindBy(xpath="//span[normalize-space()='The Coca-Cola Company - Coke - Phase 1']")
		WebElement projectNameDrop;
		
		@FindBy(xpath="//div[@class='oxd-select-text-input']")
		WebElement Activity;
		
		@FindBy(xpath="//span[normalize-space()='Administration']")
		WebElement ActivityDrop;
		
		@FindBy(xpath="(//input[@autocomplete='off'])[1]")
		WebElement mon;

		@FindBy(xpath="//body/div[@id='app']/div[1]/div[2]/div[2]/div[1]/form[1]/div[3]/div[2]/button[3]")
		WebElement save;

		@FindBy(xpath="//button[normalize-space()='Submit']")
		WebElement Submit;
		
		public void ClickTimeSheet() {
			TimeSheet.click();
		}
		public void ClickmyTimeSheet() {
			myTimeSheet.click();
		}
		public void ClickEdit() {
			Edit.click();
		}
		public void Clickdelete() {
			delete.click();
		}
		public void setprojectNameTS() {
			projectName.sendKeys("a");
		}
		public void setprojectNameDrop() {
			projectNameDrop.click();
		}
		public void setActivity() {
			Activity.click();
		}
		public void setActivityDrop() {
			ActivityDrop.click();
		}
		public void setMon() {
			mon.click();
		}
		public void Clicksave() {
			save.click();
		}
		public void ClickSubmit() {
			Submit.click();
		}

}





















