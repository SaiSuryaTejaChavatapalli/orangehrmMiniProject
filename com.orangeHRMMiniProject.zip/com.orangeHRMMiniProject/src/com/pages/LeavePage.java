package pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//------------------------------------------
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LeavePage {

	Logger logger = LogManager.getLogger(LeavePage.class.getName());

	WebDriver driver;
	public LeavePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(linkText="Leave")
	WebElement Leave;


	@FindBy(linkText="Apply")
	WebElement Apply;


	@FindBy(xpath ="(//div[@class='oxd-select-text-input'])[1]")
	WebElement LeaveTypeApply;

	@FindBy(xpath="//span[normalize-space()='CAN - Bereavement']")
	WebElement name;

	@FindBy(xpath="(//input[@placeholder='yyyy-mm-dd'])[1]")
	WebElement FromDate;

	@FindBy(xpath="//i[@class='oxd-icon bi-question-circle oxd-icon-button__icon --help']")
	WebElement ToDate;

	@FindBy(xpath="//div[contains(text(),'Full Day')]")
	WebElement Duration;
	@FindBy(xpath="//span[normalize-space()='Half Day - Morning']")
	WebElement DurationDrop;

	//LastApplyButton

	@FindBy(xpath="//button[normalize-space()='Apply']")
	WebElement LastApply;
	
	public void clickLeave() {
		Leave.click();
		logger.info("Leave clicked");
	}
	public void clickApply() {
		Apply.click();
		logger.info("Apply clicked");
	}
	public void clickLeaveTypeApply() {
		LeaveTypeApply.click();
		logger.info("LeaveTypeApply clicked");
	}
	public void clickname() {
		name.click();
		logger.info("dropdown  clicked");
	}
	public void setFrom(String Date) {
		FromDate.sendKeys(Date);
		logger.info("From Date set");
	}
	public void setTo() {
		ToDate.click();
		logger.info("To Date set");
	}
	/*
	public void clickDuration() {
		Duration.click();
		logger.info("Duration clicked");
	}
	public void clickDurationDrop() {
		DurationDrop.click();
		logger.info("DurationDrop clicked");
		
	}*/
	
	public void clickApplyFromApply() {
		LastApply.click();
		logger.info("LastApply clicked");
		
	}

	//Entitlement
	@FindBy(xpath="//span[normalize-space()='Entitlements']")
	WebElement Entitlement;

	@FindBy(xpath ="//a[normalize-space()='Add Entitlements']")
	WebElement AddEntitlement;

	@FindBy(xpath="//input[@placeholder='Type for hints...']")
	WebElement EmpName1;

	@FindBy(xpath="//span[normalize-space()='Peter Mac Anderson']")
	WebElement EmpNameDrop;


	@FindBy(xpath="//div[contains(text(),'-- Select --')]")
	WebElement LeaveTypeFromEnt;

	@FindBy(xpath="//span[normalize-space()='CAN - Bereavement']")
	WebElement LeaveTypeFromEntDrop;
	
	//Entitlement Field
	@FindBy(xpath="(//input[@class='oxd-input oxd-input--active'])[2]")
	WebElement EntitlementField;

	//Save Button
	@FindBy(xpath="//button[normalize-space()='Save']")
	WebElement Save;

	//Alert
	@FindBy(xpath="//button[normalize-space()='Confirm']")
	WebElement Alert;

	//Search
	@FindBy(xpath="//button[normalize-space()='Search']")
	WebElement SearchFromE;
	
	public void ClickEntitlement() {
		Entitlement.click();
	}
	public void ClickAddEntitlement() {
		AddEntitlement.click();
	}
	public void ClickEmpName1(String empName1Param) {
		EmpName1.sendKeys(empName1Param);
	}
	public void ClickEmpNameDrop() {
		EmpNameDrop.click();
	}
	public void ClickLeaveTypeFromEnt() {
		LeaveTypeFromEnt.click();
	}
	public void ClickLeaveTypeFromEntDrop() {
		LeaveTypeFromEntDrop.click();
	}
	public void setEntitlement(String Field) {
		EntitlementField.sendKeys(Field);
	}
	public void ClickSave() {
		Save.click();
	}
	public void ClickAlert() {
		Alert.click();
	}
	public void ClickSearchFromE() {
		SearchFromE.click();
	}
	
	//SCroll
	public void scroll(){
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,3000)");
		
		logger.info("Scrolling is done");
	}
	//-------------------------------------------------------------------------------------------
	//LeaveList
	@FindBy(xpath="//a[normalize-space()='Leave List']")
	WebElement LeaveList;



	@FindBy(xpath="//div[@class='oxd-table-filter']//div[1]//div[1]//div[1]//div[1]//div[2]//div[1]//div[1]//input[1]")
	WebElement FromDateLeave;



	//select the end date
	@FindBy(xpath="(//input[@placeholder='yyyy-mm-dd'])[2]")
	WebElement ToDateLeave;


	@FindBy(xpath="//div[@class='oxd-select-text-input'][normalize-space()='Select']")
	WebElement Status;



	@FindBy(xpath="//span[normalize-space()='Cancelled']")
	WebElement StatusDrop;


	//leave type
	@FindBy(xpath="(//div[contains(text(),'-- Select --')])[1]")
	WebElement LeaveType;


	@FindBy(xpath="//span[normalize-space()='CAN - Bereavement']")
	WebElement LeaveTypeDrop;


	//Employee name
	@FindBy(xpath="//input[@placeholder='Type for hints...']")
	WebElement EmpName;



	@FindBy(xpath="//span[normalize-space()='Peter Mac Anderson']")
	WebElement EmpNameDropLeave;


	//SubUnit
	@FindBy(xpath="//div[contains(text(),'-- Select --')]")
	WebElement SubUnit;


	@FindBy(xpath="//span[normalize-space()='Engineering']")
	WebElement SubUnitDrop;


	//search button
	@FindBy(xpath="//button[normalize-space()='Search']")
	WebElement Search;




	public void ClickLeaveList() {
		LeaveList.click();
	}
	public void setFromDateLeave() {
		FromDateLeave.sendKeys("2022-01-01");
	}
	public void setToDateLeave() {
		ToDateLeave.sendKeys("2022-01-01");
	}
	public void ClickStatus() {
		Status.click();
	}
	public void ClickStatusDrop() {
		StatusDrop.click();
	}
	public void ClickLeaveType() {
		LeaveType.click();
	}
	public void ClickLeaveTypeDrop() {
		LeaveTypeDrop.click();
	}
	public void setEmpName(String empNameParam) {
		EmpName.sendKeys(empNameParam);
	}
	public void ClickEmpNameDropLeave() {
		EmpNameDropLeave.click();
	}
	public void ClickSubUnit() {
		SubUnit.click();
	}
	public void ClickSubUnitDrop() {
		SubUnitDrop.click();
	}
	public void ClickSearch() {
		Search.click();
	}
}	


