package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
	WebDriver driver;
	@FindBy(how = How.NAME, using = "username") WebElement loginPageUsrName;
	@FindBy(how = How.NAME, using = "password") WebElement loginPagePassword;
	@FindBy(how = How.XPATH, using = "//button[normalize-space()='Login']") WebElement loginPageLgnBtn;

	
//	------------------------------------------------------------------------------------------
	public LoginPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	//-----------------------
	
	public void setLoginPageUsrName(String loginUsrName) {
		loginPageUsrName.sendKeys(loginUsrName);
	}
	public void setLoginPagePassword(String loginPassword) {
		loginPagePassword.sendKeys(loginPassword);
	}
	public void clickLoginPageLoginBtn() {
		loginPageLgnBtn.click();
	}

}
